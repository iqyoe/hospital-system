<div class="row">
  <div class="col-md-12">
    <img src="../img/404.png" alt="404" style="margin:5vh 33vh;">
  </div>
</div>
