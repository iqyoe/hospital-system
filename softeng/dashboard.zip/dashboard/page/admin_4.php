<div class="">
  <div class="page-title">
    <div class="title_left">
      <h3>Patients <small>Patients connected to the Blockchain</small></h3>
    </div>

  </div>


  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Patients <small>patient registered in blockchain</small></h2>
          <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Settings 1</a>
                </li>
                <li><a href="#">Settings 2</a>
                </li>
              </ul>
            </li>
            <li><a class="close-link"><i class="fa fa-close"></i></a>
            </li>
          </ul>
          <div class="clearfix"></div>
        </div>

        <div class="x_content">
          <p class="text-muted font-13 m-b-30">
          </p>
          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>NIK</th>
                <th>Name</th>
                <th>Sex</th>
                <th>Age</th>
                <th>Birthdate <small>dd/mm/yyy</small></th>
                <th>Address</th>
                <th>Phone</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>3175100909970005</td>
                <td>David</td>
                <td>Male</td>
                <td>20</td>
                <td>09/09/1997</td>
                <td><p>
                  Pondok Ranggon Cipayung
                </p></td>
                <td>081301237654</td>
              </tr>
              <tr>
                <td>3273111112960002</td>
                <td>Muhammad Iqbal</td>
                <td>Male</td>
                <td>21</td>
                <td>11/12/1996</td>
                <td><p>
                  Jalan Denki Selatan V
                </p></td>
                <td>081322811822</td>
              </tr>
              <tr>
                <td>3578200912960002</td>
                <td>Samuel Anthony</td>
                <td>Male</td>
                <td>21</td>
                <td>09/12/1996</td>
                <td><p>
                  Surabaya
                </p></td>
                <td>081232165400</td>
              </tr>
              <tr>
                <td>3175100909970005</td>
                <td>David</td>
                <td>Male</td>
                <td>20</td>
                <td>09/09/1997</td>
                <td><p>
                  Pondok Ranggon Cipayung
                </p></td>
                <td>081301237654</td>
              </tr>
              <tr>
                <td>3273111112960002</td>
                <td>Muhammad Iqbal</td>
                <td>Male</td>
                <td>21</td>
                <td>11/12/1996</td>
                <td><p>
                  Jalan Denki Selatan V
                </p></td>
                <td>081322811822</td>
              </tr>
              <tr>
                <td>3578200912960002</td>
                <td>Samuel Anthony</td>
                <td>Male</td>
                <td>21</td>
                <td>09/12/1996</td>
                <td><p>
                  Surabaya
                </p></td>
                <td>081232165400</td>
              </tr>
              <tr>
                <td>3175100909970005</td>
                <td>David</td>
                <td>Male</td>
                <td>20</td>
                <td>09/09/1997</td>
                <td><p>
                  Pondok Ranggon Cipayung
                </p></td>
                <td>081301237654</td>
              </tr>
              <tr>
                <td>3273111112960002</td>
                <td>Muhammad Iqbal</td>
                <td>Male</td>
                <td>21</td>
                <td>11/12/1996</td>
                <td><p>
                  Jalan Denki Selatan V
                </p></td>
                <td>081322811822</td>
              </tr>
              <tr>
                <td>3578200912960002</td>
                <td>Samuel Anthony</td>
                <td>Male</td>
                <td>21</td>
                <td>09/12/1996</td>
                <td><p>
                  Surabaya
                </p></td>
                <td>081232165400</td>
              </tr>
              <tr>
                <td>3175100909970005</td>
                <td>David</td>
                <td>Male</td>
                <td>20</td>
                <td>09/09/1997</td>
                <td><p>
                  Pondok Ranggon Cipayung
                </p></td>
                <td>081301237654</td>
              </tr>
              <tr>
                <td>3273111112960002</td>
                <td>Muhammad Iqbal</td>
                <td>Male</td>
                <td>21</td>
                <td>11/12/1996</td>
                <td><p>
                  Jalan Denki Selatan V
                </p></td>
                <td>081322811822</td>
              </tr>
              <tr>
                <td>3578200912960002</td>
                <td>Samuel Anthony</td>
                <td>Male</td>
                <td>21</td>
                <td>09/12/1996</td>
                <td><p>
                  Surabaya
                </p></td>
                <td>081232165400</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>Invoice <small>patient invoice to be payed</small></h2>
          <ul class="nav navbar-right panel_toolbox">
            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="#">Settings 1</a>
                </li>
                <li><a href="#">Settings 2</a>
                </li>
              </ul>
            </li>
            <li><a class="close-link"><i class="fa fa-close"></i></a>
            </li>
          </ul>
          <div class="clearfix"></div>
        </div>

        <div class="x_content">
          <p class="text-muted font-13 m-b-30">
          </p>
          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Invoice Number</th>
                <th>NIK</th>
                <th>Name</th>
                <th>Creation Date</th>
                <th>Due Date</th>
                <th>Discount Amount</th>
                <th>Status</th>
                <th>Option</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colspan="8"> No data available on the table</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
</div>
