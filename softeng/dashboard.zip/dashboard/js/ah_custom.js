// When the user clicks on <div>, open the popup
function myPop() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
