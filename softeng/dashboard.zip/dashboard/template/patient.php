<li><a href="patient.php?p=1"><i class="fa fa-home"></i>Edit Info</a></li>
