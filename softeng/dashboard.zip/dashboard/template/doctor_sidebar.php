<li><a href="dashboard.php?p=1"><i class="fa fa-home"></i>Dashboard</a></li>
<li><a href="dashboard.php?p=2"><i class="fa fa-user"></i>Patient</a></li>
<li><a href="dashboard.php?p=3"><i class="fa fa-files-o"></i>Queue List</a></li>
