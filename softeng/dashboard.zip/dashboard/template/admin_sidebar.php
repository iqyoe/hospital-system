<li><a href="dashboard.php?p=1"><i class="fa fa-home"></i>Dashboard</a></li>
<li><a href="dashboard.php?p=2"><i class="fa fa-sitemap"></i>Departement</a></li>
<li><a href="dashboard.php?p=3"><i class="fa fa-user-md"></i>Doctor</a></li>
<li><a href="dashboard.php?p=4"><i class="fa fa-user"></i>Patient</a></li>
<li><a href="dashboard.php?p=5"><i class="fa fa-money"></i>Payroll</a></li>
